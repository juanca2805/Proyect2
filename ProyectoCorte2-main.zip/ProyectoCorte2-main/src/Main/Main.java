package Main;

import Battle.Battle;

class Main {
    public static void main(String[] args) {
        Battle battle = new Battle();
        battle.start();
    }
}