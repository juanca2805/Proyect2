package Interfaces;

public interface Observer {
    void update(String pokemonName, int health);
}
